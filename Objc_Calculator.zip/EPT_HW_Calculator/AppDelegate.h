//
//  AppDelegate.h
//  EPT_HW_Calculator
//
//  Created by Natheethorn Teacharuangchit on 8/20/19.
//  Copyright © 2019 Natheethorn Teacharuangchit. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

