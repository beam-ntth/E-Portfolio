//
//  ViewController.h
//  EPT_HW_Calculator
//
//  Created by Natheethorn Teacharuangchit on 8/20/19.
//  Copyright © 2019 Natheethorn Teacharuangchit. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@property (nonatomic, strong) IBOutlet NSTextField *displaytext;
@property (nonatomic, strong) IBOutlet NSButton *button0;
@property (nonatomic, strong) IBOutlet NSButton *button1;
@property (nonatomic, strong) IBOutlet NSButton *button2;
@property (nonatomic, strong) IBOutlet NSButton *button3;
@property (nonatomic, strong) IBOutlet NSButton *button4;
@property (nonatomic, strong) IBOutlet NSButton *button5;
@property (nonatomic, strong) IBOutlet NSButton *button6;
@property (nonatomic, strong) IBOutlet NSButton *button7;
@property (nonatomic, strong) IBOutlet NSButton *button8;
@property (nonatomic, strong) IBOutlet NSButton *button9;
@property (nonatomic, strong) IBOutlet NSButton *buttonAC;
@property (nonatomic, strong) IBOutlet NSButton *buttonPlusOrMinus;
@property (nonatomic, strong) IBOutlet NSButton *buttonPercent;
@property (nonatomic, strong) IBOutlet NSButton *buttonDivide;
@property (nonatomic, strong) IBOutlet NSButton *buttonMultiply;
@property (nonatomic, strong) IBOutlet NSButton *buttonSubtract;
@property (nonatomic, strong) IBOutlet NSButton *buttonAdd;
@property (nonatomic, strong) IBOutlet NSButton *buttonEqual;
@property (nonatomic, strong) IBOutlet NSButton *buttonDot;

@property (nonatomic, strong) NSNumber *forOperation;
@property (nonatomic, strong) NSString *operation;

-(IBAction)pressButton0:(id)sender;
-(IBAction)pressButton1:(id)sender;
-(IBAction)pressButton2:(id)sender;
-(IBAction)pressButton3:(id)sender;
-(IBAction)pressButton4:(id)sender;
-(IBAction)pressButton5:(id)sender;
-(IBAction)pressButton6:(id)sender;
-(IBAction)pressButton7:(id)sender;
-(IBAction)pressButton8:(id)sender;
-(IBAction)pressButton9:(id)sender;
-(IBAction)pressButtonAC:(id)sender;
-(IBAction)pressButtonPlusOrMinus:(id)sender;
-(IBAction)pressButtonPercent:(id)sender;
-(IBAction)pressButtonDivide:(id)sender;
-(IBAction)pressButtonMultiply:(id)sender;
-(IBAction)pressButtonSubtract:(id)sender;
-(IBAction)pressButtonAdd:(id)sender;
-(IBAction)pressButtonEqual:(id)sender;
-(IBAction)pressButtonDot:(id)sender;

@end

