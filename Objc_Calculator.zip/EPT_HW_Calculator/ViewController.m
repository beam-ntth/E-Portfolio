//
//  ViewController.m
//  EPT_HW_Calculator
//
//  Created by Natheethorn Teacharuangchit on 8/20/19.
//  Copyright © 2019 Natheethorn Teacharuangchit. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

- (void)pressButton0:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"0"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton1:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"1"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton2:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"2"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton3:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"3"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton4:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"4"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton5:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"5"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton6:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"6"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton7:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"7"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton8:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"8"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButton9:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"9"];
    self.displaytext.stringValue = newValue;
}

- (void)pressButtonAC:(id)sender{
    self.displaytext.stringValue = @"";
    self.forOperation = NULL;
}

- (void)pressButtonDot:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [oldValue stringByAppendingString:@"."];
    self.displaytext.stringValue = newValue;
}

- (void)pressButtonAdd:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    self.forOperation = [num numberFromString:self.displaytext.stringValue];
    self.displaytext.stringValue = @"";
    self.operation = @"+";
}

- (void)pressButtonSubtract:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    self.forOperation = [num numberFromString:self.displaytext.stringValue];
    self.displaytext.stringValue = @"";
    self.operation = @"-";
}

- (void)pressButtonMultiply:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    self.forOperation = [num numberFromString:self.displaytext.stringValue];
    self.displaytext.stringValue = @"";
    self.operation = @"*";
}

- (void)pressButtonDivide:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    self.forOperation = [num numberFromString:self.displaytext.stringValue];
    self.displaytext.stringValue = @"";
    self.operation = @"/";
}

- (void)pressButtonPlusOrMinus:(id)sender{
    NSString *oldValue = self.displaytext.stringValue;
    NSString *newValue = [[NSString alloc] init];
    if ([oldValue containsString:@"-"]){
        newValue = [oldValue substringFromIndex:1];
    } else {
        newValue = [NSString stringWithFormat:@"-%@", oldValue];
    }
    self.displaytext.stringValue = newValue;
}

- (void)pressButtonPercent:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    self.forOperation = [num numberFromString:self.displaytext.stringValue];
    self.forOperation = [NSNumber numberWithFloat:([self.forOperation floatValue]/100)];
    
    self.displaytext.stringValue = [self.forOperation stringValue];
}

- (void)pressButtonEqual:(id)sender{
    NSNumberFormatter *num = [[NSNumberFormatter alloc] init];
    num.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *newnum = [num numberFromString:self.displaytext.stringValue];
    if ([self.operation isEqualToString:@"+"]){
        newnum = [NSNumber numberWithFloat: ([self.forOperation floatValue] + [newnum floatValue])];
    } else if ([self.operation isEqualToString:@"-"]){
        newnum = [NSNumber numberWithFloat: ([self.forOperation floatValue] - [newnum floatValue])];
    } else if ([self.operation isEqualToString:@"*"]){
        newnum = [NSNumber numberWithFloat: ([self.forOperation floatValue] * [newnum floatValue])];
    } else {
        newnum = [NSNumber numberWithFloat: ([self.forOperation floatValue] / [newnum floatValue])];
    }
    self.displaytext.stringValue = [newnum stringValue];
}


@end
