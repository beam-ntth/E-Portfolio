//
//  main.m
//  EPT_HW_Calculator
//
//  Created by Natheethorn Teacharuangchit on 8/20/19.
//  Copyright © 2019 Natheethorn Teacharuangchit. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
