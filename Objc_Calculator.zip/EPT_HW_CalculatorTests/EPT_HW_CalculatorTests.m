//
//  EPT_HW_CalculatorTests.m
//  EPT_HW_CalculatorTests
//
//  Created by Natheethorn Teacharuangchit on 8/20/19.
//  Copyright © 2019 Natheethorn Teacharuangchit. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface EPT_HW_CalculatorTests : XCTestCase

@end

@implementation EPT_HW_CalculatorTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
